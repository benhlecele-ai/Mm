# Mountain Movers — Furniture Removals & Storage

Production-ready single-page static website.

## Stack
- Semantic HTML5
- Tailwind CSS via CDN
- Custom JavaScript
- GSAP + ScrollTrigger
- Responsive design

## Run
Open `index.html` in a browser.

## Deploy
Upload the repository to GitHub and enable GitHub Pages, or deploy the folder to Netlify/Vercel.

## Notes
The supplied Facebook destination was not a specific page, so the Facebook button uses a generic Facebook URL.
The map is centered on South Africa because no exact office/service address was supplied.
